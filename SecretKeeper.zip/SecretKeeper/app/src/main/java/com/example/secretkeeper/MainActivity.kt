package com.example.secretkeeper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.secretkeeper.ui.theme.SecretKeeperTheme
import java.io.File

class MainActivity : ComponentActivity() {

    private var selectedFileUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SecretKeeperTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MainScreen(
                        modifier = Modifier.padding(innerPadding),
                        onSelectFileClick = { selectFile() },
                        onEncryptClick = { encryptFile() },
                        onDecryptClick = { decryptFile() }
                    )
                }
            }
        }
    }

    // File Select
    private val selectFileLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                selectedFileUri = uri
                showToast("File selected: $uri")
            } else {
                showToast("No file selected")
            }
        }

    private fun selectFile() {
        selectFileLauncher.launch("*/*")
    }

    private fun uriToFile(uri: Uri): File? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val tempFile = File.createTempFile("temp", null, cacheDir)
            inputStream?.use { input ->
                tempFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            tempFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun encryptFile() {
        if (selectedFileUri != null) {
            val inputFile = uriToFile(selectedFileUri!!) ?: run {
                showToast("Failed to access file")
                return
            }
            val encryptedFile = File(filesDir, "encrypted_${inputFile.name}")

            val fileEncryptor = FileEncryptor(this)
            if (fileEncryptor.encryptFile(inputFile, encryptedFile)) {
                showToast("File encrypted successfully!")
            } else {
                showToast("Encryption failed.")
            }
        } else {
            showToast("No file selected")
        }
    }

    private fun decryptFile() {
        val encryptedFileName = "encrypted_${selectedFileUri?.lastPathSegment ?: "default"}"
        val encryptedFile = File(filesDir, encryptedFileName)
        val decryptedFile = File(filesDir, "decrypted_${selectedFileUri?.lastPathSegment ?: "default"}")

        if (!encryptedFile.exists()) {
            showToast("Encrypted file not found")
            return
        }

        val fileEncryptor = FileEncryptor(this)
        if (fileEncryptor.decryptFile(encryptedFile, decryptedFile)) {
            showToast("File decrypted successfully!")
        } else {
            showToast("Decryption failed.")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun MainScreen(
    modifier: Modifier = Modifier,
    onSelectFileClick: () -> Unit,
    onEncryptClick: () -> Unit,
    onDecryptClick: () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(
            onClick = onSelectFileClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Select File")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onEncryptClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Encrypt File")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onDecryptClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Decrypt File")
        }
    }
}
